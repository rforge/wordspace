library(testthat)
library(wordspace)

test_check("wordspace")
